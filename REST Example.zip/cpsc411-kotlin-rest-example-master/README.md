# REST Example

To start the REST API, type the following from the Terminal window in Android Studio:

    $ cd web
    $ ./gradlew run

When Javalin has started you should be able to access the API from inside
the emulator at http://10.0.2.2:7000/.

